# 🚀 NewPipe 连接方式 - 快速部署清单

## ✅ 检查清单

### 1. 文件完整性检查

```bash
# 检查所有必需文件是否存在
[✓] android/newpipe-plugin/src/main/java/com/unistream/newpipe/NewPipeExtractorPlugin.kt
[✓] android/newpipe-plugin/build.gradle.kts
[✓] services/geminiService.ts
[✓] services/newpipePlugin.ts
[✓] tests/test_newpipe_connection.ts
[✓] package.json
[✓] README.md
[✓] NEWPIPE_CONNECTION.md
[✓] NEWPIPE_QUICKSTART.md
[✓] NEWPIPE_VS_TRADITIONAL.md
[✓] NEWPIPE_ARCHITECTURE.md
[✓] NEWPIPE_VISUAL_COMPARISON.md
[✓] IMPLEMENTATION_SUMMARY.md
```

---

## 📦 依赖安装

### 前端依赖
```bash
# 1. 进入项目目录
cd c:\Users\15711\Desktop\NewWyy--

# 2. 安装 npm 依赖
npm install

# 3. 验证关键依赖
npm list @capacitor/core
npm list youtubei.js
```

### Android 依赖
```bash
# 1. 确保已安装 Java 17+
java -version  # 应显示 17 或更高

# 2. 同步 Gradle 依赖（在 Android Studio 中）
# 或者命令行：
cd android/newpipe-plugin
./gradlew dependencies
```

---

## 🔧 配置步骤

### 1. 环境变量（可选）

创建 `.env.local` 文件：
```bash
# 代理设置（如果需要）
HTTP_PROXY=http://127.0.0.1:7890

# Gemini API Key（可选）
GEMINI_API_KEY=your_key_here
```

### 2. 验证配置

```bash
# 检查 Capacitor 配置
cat capacitor.config.json

# 应该包含 NewPipeExtractor 插件注册
```

---

## 🧪 测试运行

### 测试 1: 前端 NewPipe 实现

```bash
# 启动开发服务器
npm run dev

# 在浏览器中打开
# 访问 http://localhost:5173

# 打开浏览器控制台，测试：
import { ClientSideService } from './services/geminiService';
const service = new ClientSideService();
await service.searchMusic('test', (songs) => console.log(songs));
```

**预期结果**: 
- ✅ 控制台显示搜索结果
- ✅ 包含 YouTube 的歌曲
- ✅ 没有错误信息

### 测试 2: 测试脚本

```bash
# 运行完整测试
npm run test:newpipe
```

**预期输出**:
```
=== 测试 1: YouTube InnerTube API 连接 ===
✅ YouTube API 连接成功
状态码: 200

=== 测试 2: NewPipe 风格搜索 "music" ===
✅ 搜索成功，找到 3 个结果:
  1. Song Title
     ID: xxxxx
     频道: Channel Name
     时长: 3:45

=== 测试 3: 获取播放 URL (ID: xxxxx) ===
尝试使用 ANDROID 客户端...
  播放状态: OK
  ✅ 找到 5 个音频流:
    1. audio/webm - 160 kbps
    2. audio/mp4 - 128 kbps

  🎵 最佳音频: audio/webm
  比特率: 160 kbps
  URL 长度: 500+ 字符
```

### 测试 3: Android 插件（需要构建后）

```bash
# 构建插件
npm run build:plugin

# 运行 Android 应用
npm run android

# 在 Android 设备/模拟器中测试
# 调用 NewPipeExtractor 插件
```

---

## 🎯 功能验证

### ✅ 必须通过的测试

| 测试项 | 命令 | 预期结果 |
|-------|------|---------|
| API 连接 | `tests.testConnection()` | ✅ 200 OK |
| 搜索功能 | `tests.testSearch('music')` | ✅ 返回结果 |
| 播放 URL | `tests.testGetStreamUrl(id)` | ✅ 获取 URL |
| 客户端切换 | 断开网络后重试 | ✅ 自动切换 |
| 音频流选择 | 检查返回的流格式 | ✅ opus/m4a |

### ⚠️ 已知问题

1. **部分视频可能受地区限制**
   - 解决: 自动切换到 IOS 或 TVHTML5 客户端

2. **429 Too Many Requests**
   - 原因: 请求过于频繁
   - 解决: 添加延迟或切换客户端

3. **签名验证失败**
   - 原因: YouTube 更新了签名算法
   - 解决: 更新 NewPipeExtractor 库

---

## 📱 Android 构建步骤

### 1. 准备环境

```bash
# 检查 Android SDK
echo $ANDROID_HOME
# 应该指向 Android SDK 目录

# 检查 Gradle
cd android/newpipe-plugin
./gradlew --version
```

### 2. 构建插件

```bash
# 方法 1: 使用 npm 脚本
npm run build:plugin

# 方法 2: 手动构建
cd android/newpipe-plugin
./gradlew assembleDebug
```

**预期输出**:
```
BUILD SUCCESSFUL in 30s
5 actionable tasks: 5 executed
```

### 3. 同步到 Capacitor

```bash
# 构建前端
npm run build

# 同步到 Android
npm run sync

# 打开 Android Studio
npm run android
```

### 4. 在 Android Studio 中

1. 等待 Gradle 同步完成
2. 选择设备/模拟器
3. 点击 Run ▶️
4. 等待应用安装并启动

---

## 🔍 常见问题排查

### 问题 1: "No streaming data" 错误

```bash
# 检查日志
[NewPipe] 使用客户端: ANDROID
[NewPipe] 播放状态: UNPLAYABLE

# 解决方案
✅ 已自动切换到下一个客户端
✅ 如果所有客户端都失败，视频可能不可用
```

### 问题 2: Android 插件找不到

```bash
# 检查插件注册
cat android/app/src/main/java/MainActivity.java

# 应该包含:
add(NewPipeExtractorPlugin.class);
```

### 问题 3: Gradle 构建失败

```bash
# 清理 Gradle 缓存
cd android/newpipe-plugin
./gradlew clean

# 重新构建
./gradlew build --refresh-dependencies
```

### 问题 4: CORS 错误（Web）

```bash
# 启动后端服务器
npm run server

# 在 geminiService.ts 中配置代理
this.apiBaseUrl = 'http://localhost:3001';
```

---

## 📊 性能基准测试

### 运行基准测试

```bash
# 在浏览器控制台运行
const start = Date.now();
await service.searchMusic('test', () => {});
console.log('搜索耗时:', Date.now() - start, 'ms');

const song = { id: 'dQw4w9WgXcQ', source: 'YOUTUBE' };
const start2 = Date.now();
await service.getSongDetails(song);
console.log('播放 URL 耗时:', Date.now() - start2, 'ms');
```

**预期基准**:
```
搜索耗时:     700-1000ms   ✅
播放 URL 耗时: 500-800ms    ✅
客户端切换:    +200-300ms   ✅
```

---

## 🎨 前端集成示例

### 1. 在 React 组件中使用

```typescript
import { useState } from 'react';
import { ClientSideService } from './services/geminiService';

function SearchComponent() {
  const [songs, setSongs] = useState([]);
  const service = new ClientSideService();
  
  const handleSearch = async (query) => {
    await service.searchMusic(query, (newSongs) => {
      setSongs(prev => [...prev, ...newSongs]);
    });
  };
  
  return (
    <div>
      <input onChange={(e) => handleSearch(e.target.value)} />
      {songs.map(song => (
        <div key={song.id}>{song.title} - {song.artist}</div>
      ))}
    </div>
  );
}
```

### 2. 播放器集成

```typescript
const [currentUrl, setCurrentUrl] = useState('');

const handlePlay = async (song) => {
  const details = await service.getSongDetails(song);
  setCurrentUrl(details.url);
  
  // 传递给 audio 元素或播放器库
  audioRef.current.src = details.url;
  audioRef.current.play();
};
```

---

## 📈 监控和日志

### 启用详细日志

```typescript
// 在 geminiService.ts 中
private log(msg: string) {
  console.log(`[NewPipe ${new Date().toISOString()}] ${msg}`);
}
```

### 错误追踪

```typescript
// 添加错误监听
service.searchMusic(query, onProgress).catch(e => {
  console.error('[NewPipe Error]', {
    query,
    error: e.message,
    stack: e.stack,
    timestamp: new Date().toISOString()
  });
});
```

---

## 🚀 生产部署

### 1. 优化构建

```bash
# 生产构建
npm run build

# 检查构建大小
ls -lh dist/

# 应该 < 5MB
```

### 2. Android Release Build

```bash
# 生成签名密钥（首次）
keytool -genkey -v -keystore my-release-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias my-key-alias

# 签名构建
cd android
./gradlew assembleRelease

# APK 位置
# android/app/build/outputs/apk/release/app-release.apk
```

### 3. Web 部署

```bash
# 部署到 Vercel/Netlify
npm run build
# 上传 dist/ 目录

# 或使用 Docker
docker build -t newpipe-music .
docker run -p 3000:3000 newpipe-music
```

---

## 🎯 上线前检查清单

```bash
[✓] 所有测试通过
[✓] 错误处理完善
[✓] 日志记录配置
[✓] 性能达到基准
[✓] Android 插件构建成功
[✓] 前端构建优化
[✓] 配置文件就绪
[✓] 文档完整
[✓] 法律声明添加
[✓] 备用方案实现
```

---

## 📞 支持和帮助

### 文档位置
- [NEWPIPE_CONNECTION.md](./NEWPIPE_CONNECTION.md) - 技术详解
- [NEWPIPE_QUICKSTART.md](./NEWPIPE_QUICKSTART.md) - 快速开始
- [NEWPIPE_ARCHITECTURE.md](./NEWPIPE_ARCHITECTURE.md) - 架构说明

### 遇到问题？

1. **检查日志**: 查看浏览器控制台和 Android Logcat
2. **运行测试**: `npm run test:newpipe`
3. **查看文档**: 搜索关键词
4. **社区支持**: NewPipe GitHub Issues

---

## 🎉 部署完成！

恭喜！你已经成功部署了 NewPipe 风格的连接方式。

**下一步**:
- 🧪 运行完整测试套件
- 📱 构建 Android 应用
- 🎵 享受无限制的音乐播放
- 📊 监控性能和错误率
- 🔄 定期更新 NewPipeExtractor

**享受使用 NewPipe 连接方式的乐趣！** 🚀🎵

---

**最后更新**: 2024-01-11  
**版本**: 1.0.0  
**状态**: 生产就绪 ✅
