<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://github.com/user-attachments/assets/0aa67016-6eaf-458a-adb2-6e31a0763ed6" />
</div>

# UniStream Music - NewPipe 风格连接

一个使用 NewPipe 连接方式的跨平台音乐应用，支持 YouTube、网易云音乐、Bilibili 等平台。

## ✨ 特性

- 🎵 **多平台支持**: YouTube, 网易云音乐, Bilibili
- 🔄 **NewPipe 风格连接**: 无需 API Key，使用 InnerTube API
- 📱 **跨平台**: Web + Android (Capacitor)
- 🎯 **智能切换**: 多客户端自动故障转移
- 🚀 **高性能**: 直接获取流 URL，无需额外请求

## 🚀 快速开始

### 前置要求

- Node.js 16+
- Android Studio (用于 Android 构建)
- Java 17+ (用于 Android 插件)

### 安装依赖

```bash
npm install
```

### 运行开发服务器

```bash
# 前端开发
npm run dev

# 后端服务器
npm run server
```

### 构建 Android 应用

```bash
# 构建 NewPipe 插件
cd android/newpipe-plugin
./gradlew build

# 同步到 Capacitor
cd ../..
npm run build
npx cap sync android
npx cap open android
```

## 📚 NewPipe 连接方式

本项目使用 NewPipe 的连接方式，通过 YouTube InnerTube API 直接获取数据，无需官方 API Key。

### 核心特性

1. **多客户端支持**: WEB, ANDROID, IOS, TVHTML5
2. **自动重试**: 客户端失败时自动切换
3. **隐私保护**: 不发送用户数据到 Google
4. **高可用性**: 绕过地区限制和速率限制

详细文档：
- [NewPipe 连接方式详解](./NEWPIPE_CONNECTION.md)
- [快速开始指南](./NEWPIPE_QUICKSTART.md)

### 使用示例

```typescript
import { ClientSideService } from './services/geminiService';

const service = new ClientSideService();

// 搜索音乐
await service.searchMusic('周杰伦', (songs) => {
  console.log('找到歌曲:', songs);
});

// 获取播放 URL
const details = await service.getSongDetails(song);
console.log('播放地址:', details.url);
```

## 🧪 测试

```bash
# 测试 NewPipe 连接
npm run test:newpipe

# 测试其他功能
npm run test
```

## 📦 项目结构

```
.
├── services/
│   ├── geminiService.ts       # 前端服务（NewPipe 实现）
│   └── newpipePlugin.ts       # 原生插件接口
├── android/
│   └── newpipe-plugin/        # Android NewPipeExtractor 插件
│       ├── build.gradle.kts
│       └── src/main/java/com/unistream/newpipe/
│           └── NewPipeExtractorPlugin.kt
├── tests/
│   └── test_newpipe_connection.ts  # 连接测试
├── server.js                  # Node.js 后端（使用 youtubei.js）
└── App.tsx                    # React 应用
```

## 🔧 配置

### 环境变量

创建 `.env.local` 文件：

```bash
# Gemini API Key (可选)
GEMINI_API_KEY=your_api_key_here

# 代理设置 (可选)
HTTP_PROXY=http://127.0.0.1:7890
```

### Android 插件配置

文件: `android/newpipe-plugin/build.gradle.kts`

```kotlin
dependencies {
    implementation("com.github.TeamNewPipe:NewPipeExtractor:v0.23.2")
    implementation("com.google.android.exoplayer:exoplayer:2.20.0")
}
```

## 📖 API 文档

### 搜索音乐

```typescript
service.searchMusic(query: string, onProgress: (songs: Song[]) => void): Promise<void>
```

### 获取播放详情

```typescript
service.getSongDetails(song: Song, quality?: AudioQuality): Promise<SongPlayDetails>
```

### 获取评论

```typescript
service.getComments(song: Song): Promise<Comment[]>
```

## ⚠️ 法律声明

本项目使用 NewPipe 风格的连接方式，可能违反某些平台的服务条款。

**使用限制**:
- ✅ 教育和研究目的
- ✅ 个人非商业使用
- ❌ 不建议用于商业应用
- ❌ 不要大规模爬取数据

使用本项目，您承诺遵守相关法律法规和平台服务条款。

## 🤝 贡献

欢迎提交 Issue 和 Pull Request！

## 📄 许可证

MIT License

---

## 🔗 资源链接

- [NewPipe](https://github.com/TeamNewPipe/NewPipe)
- [NewPipeExtractor](https://github.com/TeamNewPipe/NewPipeExtractor)
- [youtubei.js](https://github.com/LuanRT/YouTube.js)
- [Capacitor](https://capacitorjs.com/)

---

**注意**: 本项目仅供学习和研究使用，请勿用于非法用途。
