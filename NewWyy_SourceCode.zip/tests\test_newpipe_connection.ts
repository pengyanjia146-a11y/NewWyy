/**
 * NewPipe 连接方式测试脚本
 * 
 * 测试内容：
 * 1. YouTube InnerTube API 连接
 * 2. 多客户端切换
 * 3. 搜索功能
 * 4. 播放 URL 获取
 */

import { CapacitorHttp } from '@capacitor/core';

// NewPipe 配置
const INNERTUBE_API_KEY = "AIzaSyC282fI7k5OmaVhWuC8kqV7M1r2s";
const YOUTUBEI_V1_URL = "https://www.youtube.com/youtubei/v1";

const CLIENTS = {
    WEB: {
        context: {
            client: {
                clientName: "WEB",
                clientVersion: "2.20240111.00.00",
                hl: "en",
                gl: "US",
                userAgent: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
            }
        }
    },
    ANDROID: {
        context: {
            client: {
                clientName: "ANDROID",
                clientVersion: "19.09.37",
                androidSdkVersion: 33,
                hl: "en",
                gl: "US",
                userAgent: "com.google.android.youtube/19.09.37 (Linux; U; Android 13)"
            }
        }
    }
};

/**
 * 测试 1: YouTube API 连接性
 */
async function testConnection() {
    console.log("\n=== 测试 1: YouTube InnerTube API 连接 ===");
    
    try {
        const response = await CapacitorHttp.get({
            url: `${YOUTUBEI_V1_URL}/guide?key=${INNERTUBE_API_KEY}`,
            headers: {
                'User-Agent': 'Mozilla/5.0',
                'Accept': 'application/json'
            }
        });
        
        console.log("✅ YouTube API 连接成功");
        console.log(`状态码: ${response.status}`);
        return true;
    } catch (e: any) {
        console.log("❌ YouTube API 连接失败");
        console.log(`错误: ${e.message}`);
        return false;
    }
}

/**
 * 测试 2: 搜索功能
 */
async function testSearch(query: string = "music") {
    console.log(`\n=== 测试 2: NewPipe 风格搜索 "${query}" ===`);
    
    try {
        const response = await CapacitorHttp.post({
            url: `${YOUTUBEI_V1_URL}/search?key=${INNERTUBE_API_KEY}`,
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': CLIENTS.WEB.context.client.userAgent,
                'Accept-Language': 'en-US,en;q=0.9',
                'Origin': 'https://www.youtube.com',
                'Referer': 'https://www.youtube.com/'
            },
            data: {
                ...CLIENTS.WEB,
                query: query,
                params: "EgIQAQ%3D%3D"  // 只搜索视频
            }
        });
        
        if (response.status === 200) {
            const json = typeof response.data === 'string' ? JSON.parse(response.data) : response.data;
            const contents = json.contents?.twoColumnSearchResultsRenderer?.primaryContents?.sectionListRenderer?.contents?.[0]?.itemSectionRenderer?.contents;
            
            if (Array.isArray(contents)) {
                const videos = contents.filter((item: any) => item.videoRenderer).slice(0, 3);
                console.log(`✅ 搜索成功，找到 ${videos.length} 个结果:`);
                
                videos.forEach((item: any, index: number) => {
                    const video = item.videoRenderer;
                    console.log(`\n  ${index + 1}. ${video.title?.runs?.[0]?.text || 'Unknown'}`);
                    console.log(`     ID: ${video.videoId}`);
                    console.log(`     频道: ${video.ownerText?.runs?.[0]?.text || 'Unknown'}`);
                    console.log(`     时长: ${video.lengthText?.simpleText || 'Unknown'}`);
                });
                
                return videos[0]?.videoRenderer?.videoId; // 返回第一个视频ID用于后续测试
            }
        }
        
        console.log("❌ 搜索失败：未找到结果");
        return null;
    } catch (e: any) {
        console.log("❌ 搜索失败");
        console.log(`错误: ${e.message}`);
        return null;
    }
}

/**
 * 测试 3: 获取播放 URL（多客户端策略）
 */
async function testGetStreamUrl(videoId: string) {
    console.log(`\n=== 测试 3: 获取播放 URL (ID: ${videoId}) ===`);
    
    const clientList = [
        { name: "ANDROID", client: CLIENTS.ANDROID },
        { name: "WEB", client: CLIENTS.WEB }
    ];
    
    for (const { name, client } of clientList) {
        console.log(`\n尝试使用 ${name} 客户端...`);
        
        try {
            const response = await CapacitorHttp.post({
                url: `${YOUTUBEI_V1_URL}/player?key=${INNERTUBE_API_KEY}`,
                headers: {
                    'Content-Type': 'application/json',
                    'User-Agent': client.context.client.userAgent,
                    'Accept-Language': 'en-US,en;q=0.9',
                    'Origin': 'https://www.youtube.com',
                    'Referer': 'https://www.youtube.com/'
                },
                data: {
                    ...client,
                    videoId: videoId,
                    contentCheckOk: true,
                    racyCheckOk: true
                }
            });
            
            if (response.status === 200) {
                const json = typeof response.data === 'string' ? JSON.parse(response.data) : response.data;
                
                // 检查播放状态
                const playabilityStatus = json.playabilityStatus?.status;
                console.log(`  播放状态: ${playabilityStatus}`);
                
                if (playabilityStatus !== 'OK') {
                    console.log(`  ⚠️ 原因: ${json.playabilityStatus?.reason || 'Unknown'}`);
                    continue;
                }
                
                const streamingData = json.streamingData;
                if (!streamingData) {
                    console.log("  ⚠️ 没有流数据");
                    continue;
                }
                
                // 分析音频流
                const formats = [...(streamingData.formats || []), ...(streamingData.adaptiveFormats || [])];
                const audioFormats = formats.filter((f: any) => f.mimeType?.includes("audio"));
                
                console.log(`  ✅ 找到 ${audioFormats.length} 个音频流:`);
                
                audioFormats.slice(0, 3).forEach((format: any, index: number) => {
                    const bitrate = Math.round((format.bitrate || 0) / 1000);
                    const mimeType = format.mimeType?.split(';')[0] || 'Unknown';
                    console.log(`    ${index + 1}. ${mimeType} - ${bitrate} kbps`);
                });
                
                // 选择最佳音频流
                const opus = audioFormats.find((f: any) => f.mimeType.includes("opus"));
                const m4a = audioFormats.find((f: any) => f.mimeType.includes("mp4"));
                const bestAudio = opus || m4a || audioFormats[0];
                
                if (bestAudio) {
                    const urlLength = bestAudio.url?.length || 0;
                    console.log(`\n  🎵 最佳音频: ${bestAudio.mimeType?.split(';')[0]}`);
                    console.log(`  比特率: ${Math.round(bestAudio.bitrate / 1000)} kbps`);
                    console.log(`  URL 长度: ${urlLength} 字符`);
                    console.log(`  URL 前缀: ${bestAudio.url?.substring(0, 50)}...`);
                    
                    return bestAudio.url;
                }
            }
            
        } catch (e: any) {
            console.log(`  ❌ ${name} 客户端失败: ${e.message}`);
        }
    }
    
    console.log("\n❌ 所有客户端均失败");
    return null;
}

/**
 * 测试 4: 完整流程测试
 */
async function testFullWorkflow() {
    console.log("\n========================================");
    console.log("    NewPipe 连接方式完整测试");
    console.log("========================================");
    
    const startTime = Date.now();
    
    // 测试 1: 连接
    const connected = await testConnection();
    if (!connected) {
        console.log("\n⚠️ API 连接失败，可能需要检查网络或代理设置");
        return;
    }
    
    // 等待一下
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // 测试 2: 搜索
    const videoId = await testSearch("周杰伦");
    if (!videoId) {
        console.log("\n⚠️ 搜索失败，使用默认视频ID进行测试");
        // 使用一个已知的视频ID
        await testGetStreamUrl("dQw4w9WgXcQ");
    } else {
        // 等待一下
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // 测试 3: 获取播放URL
        await testGetStreamUrl(videoId);
    }
    
    const elapsed = Date.now() - startTime;
    console.log("\n========================================");
    console.log(`测试完成，耗时: ${(elapsed / 1000).toFixed(2)} 秒`);
    console.log("========================================\n");
}

/**
 * 主函数
 */
export async function runNewPipeTests() {
    try {
        await testFullWorkflow();
    } catch (e: any) {
        console.error("测试过程中发生错误:", e);
    }
}

// 如果直接运行此脚本
if (require.main === module) {
    runNewPipeTests();
}

export default {
    testConnection,
    testSearch,
    testGetStreamUrl,
    runNewPipeTests
};
