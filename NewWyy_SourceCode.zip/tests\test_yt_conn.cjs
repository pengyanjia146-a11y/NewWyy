const https = require('https');
console.log('Starting test request to https://www.youtube.com');
https.get('https://www.youtube.com', res => {
  console.log('status', res.statusCode);
  res.resume();
}).on('error', e => {
  console.error('err', e.message);
});
