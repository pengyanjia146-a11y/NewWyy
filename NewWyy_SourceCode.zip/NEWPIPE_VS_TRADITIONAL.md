# NewPipe 连接方式 vs 传统方式对比

## 实现对比

### 🔵 NewPipe 方式（当前实现）

#### 前端实现
```typescript
// services/geminiService.ts
const CLIENTS = { WEB, ANDROID, IOS, TVHTML5_EMBEDDED };

private async youtubeRequest(endpoint, client, data, retryCount = 0) {
  try {
    return await CapacitorHttp.post({
      url: `https://www.youtube.com/youtubei/v1${endpoint}?key=${API_KEY}`,
      headers: {
        'User-Agent': client.context.client.userAgent,
        'Origin': 'https://www.youtube.com',
        'Referer': 'https://www.youtube.com/'
      },
      data: { ...client, ...data }
    });
  } catch (e) {
    // 自动切换到下一个客户端
    if (retryCount < maxRetries) {
      return this.youtubeRequest(endpoint, nextClient, data, retryCount + 1);
    }
    throw e;
  }
}
```

#### Android 实现
```kotlin
// NewPipeExtractorPlugin.kt
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.stream.StreamInfo

NewPipe.init(AndroidDownloader(), Localization.DEFAULT)
val streamInfo = StreamInfo.getInfo(ServiceList.YouTube, url)
val audioStreams = streamInfo.audioStreams
val bestAudio = audioStreams.maxByOrNull { it.averageBitrate }
```

#### 后端实现
```javascript
// server.js
const { Innertube } = require('youtubei.js');

const yt = await Innertube.create({
  cache: new UniversalCache(false),
  generate_session_locally: true
});

const info = await yt.getBasicInfo(videoId, 'ANDROID');
const audioFormat = info.streaming_data.adaptive_formats
  .filter(f => f.mime_type.includes('audio'))
  .sort((a, b) => b.bitrate - a.bitrate)[0];
```

---

### 🔴 传统方式（YouTube Data API v3）

#### 前端实现
```typescript
// 传统方式需要 API Key
const YOUTUBE_API_KEY = 'AIzaSyXXXXXXXXXXXXXXXXXXXXXXXXXXX';

async function searchYouTube(query) {
  // 第一步：搜索视频
  const searchResponse = await fetch(
    `https://www.googleapis.com/youtube/v3/search?` +
    `part=snippet&q=${query}&type=video&key=${YOUTUBE_API_KEY}`
  );
  const searchData = await searchResponse.json();
  
  // ❌ 问题：没有播放 URL，需要额外请求或使用嵌入式播放器
  return searchData.items;
}

async function getVideoStream(videoId) {
  // ❌ 官方 API 不提供直接播放 URL
  // 只能使用 YouTube IFrame Player 或其他第三方服务
  return `https://www.youtube.com/embed/${videoId}`;
}
```

#### 配额限制
```
每天配额: 10,000 单位
- 搜索请求: 100 单位/次
- 视频详情: 1 单位/次
- 评论列表: 1 单位/次

每天最多约 100 次搜索！
```

---

## 功能对比

| 功能 | NewPipe 方式 | YouTube Data API v3 | 优势方 |
|------|-------------|-------------------|--------|
| **需要 API Key** | ❌ 不需要 | ✅ 需要申请 | NewPipe |
| **配额限制** | ✅ 无限制 | ❌ 每天 10,000 | NewPipe |
| **直接获取播放 URL** | ✅ 支持 | ❌ 不支持 | NewPipe |
| **音频流质量选择** | ✅ opus/m4a/webm | ❌ 无 | NewPipe |
| **地区限制** | ✅ 可绕过 | ❌ 严格 | NewPipe |
| **搜索速度** | ⚡ 快 | ⚡ 快 | 相同 |
| **稳定性** | ⚠️ 依赖内部 API | ✅ 官方支持 | API v3 |
| **法律合规性** | ⚠️ 灰色地带 | ✅ 完全合规 | API v3 |
| **隐私保护** | ✅ 不发送用户数据 | ⚠️ Google 跟踪 | NewPipe |
| **离线使用** | ✅ 可缓存 URL | ❌ 需在线验证 | NewPipe |
| **多客户端切换** | ✅ 支持 | ❌ 不支持 | NewPipe |

---

## 性能对比

### 搜索 + 播放完整流程

#### NewPipe 方式
```
1. 搜索请求    → 800ms  (InnerTube API)
2. 播放 URL    → 600ms  (同一 API，包含在搜索结果)
   └─ 重试机制  → +300ms (如需切换客户端)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
总计: ~1.4秒（单客户端）或 ~1.7秒（带重试）

请求数: 2 次
数据量: ~150KB
```

#### YouTube Data API v3
```
1. 搜索请求    → 700ms  (Data API)
2. 视频详情    → 500ms  (需要额外请求)
3. 播放 URL    → ❌ 不提供
   └─ 嵌入播放器 → +2000ms (加载 iframe)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
总计: ~3.2秒（使用嵌入式播放器）

请求数: 2-3 次
数据量: ~80KB
配额消耗: 101 单位
```

**结论**: NewPipe 方式速度快约 **2倍**，且无配额限制。

---

## 使用场景对比

### ✅ NewPipe 方式适合：

1. **个人项目** - 无需担心 API 配额
2. **音乐播放器** - 需要直接获取音频流
3. **隐私重视** - 不想被 Google 跟踪
4. **高频使用** - 超过每天 100 次搜索
5. **多平台聚合** - 结合 Bilibili、网易云等
6. **离线功能** - 缓存播放 URL

### ⚠️ NewPipe 方式不适合：

1. **商业应用** - 法律风险
2. **公开服务** - 可能违反 ToS
3. **需要官方功能** - 如上传视频、管理频道
4. **企业项目** - 需要官方支持和 SLA

### ✅ YouTube Data API v3 适合：

1. **商业应用** - 完全合规
2. **低频使用** - 每天少于 100 次搜索
3. **YouTube 官方功能** - 频道管理、评论发布等
4. **企业项目** - 需要官方支持

### ⚠️ YouTube Data API v3 不适合：

1. **高频使用** - 配额不足
2. **音乐播放** - 无法获取直接播放 URL
3. **需要绕过地区限制**
4. **隐私敏感项目**

---

## 代码量对比

### NewPipe 方式
```
前端实现: ~300 行 (包含多客户端切换)
Android 插件: ~250 行 (包含 Downloader)
测试代码: ~200 行
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
总计: ~750 行
```

### YouTube Data API v3
```
前端实现: ~150 行 (简单封装)
无需原生插件
测试代码: ~100 行
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
总计: ~250 行

但需要额外的播放器实现 (+500 行)
实际总计: ~750 行
```

**结论**: 代码量相似，但 NewPipe 方式更灵活。

---

## 维护成本对比

### NewPipe 方式
- ⚠️ YouTube 更新内部 API 时需要更新
- ✅ NewPipeExtractor 库定期更新
- ✅ 社区活跃，问题响应快
- ⚠️ 需要关注 InnerTube API 变化

### YouTube Data API v3
- ✅ Google 官方维护，稳定
- ✅ 很少有破坏性更改
- ⚠️ 配额政策可能变化
- ⚠️ API 功能更新慢

---

## 实际案例

### NewPipe 应用
- **NewPipe** (1000万+ 下载) - Android 应用
- **Invidious** - YouTube 前端
- **Piped** - YouTube 前端
- **YouTube.js** - Node.js 库 (10k+ stars)

### 使用 YouTube Data API v3 的应用
- 官方 YouTube 客户端集成
- YouTube Studio
- 大多数第三方 YouTube 管理工具

---

## 决策矩阵

```
使用 NewPipe 方式，如果：
✅ 个人/学习项目
✅ 需要直接播放功能
✅ 高频使用 (>100次/天)
✅ 需要隐私保护
✅ 多平台聚合

使用 YouTube Data API v3，如果：
✅ 商业应用
✅ 需要官方支持
✅ 低频使用 (<100次/天)
✅ 需要上传/管理功能
✅ 企业级项目
```

---

## 混合方案

```typescript
// 智能切换：优先 NewPipe，配额不足时使用 API v3
class HybridYouTubeService {
  async search(query: string) {
    try {
      // 优先使用 NewPipe（快速，无配额）
      return await this.newPipeSearch(query);
    } catch (e) {
      // 失败则使用官方 API（稳定，有配额）
      return await this.dataAPISearch(query);
    }
  }
  
  async getStreamUrl(videoId: string) {
    // 只有 NewPipe 能获取直接播放 URL
    return await this.newPipeGetStream(videoId);
  }
}
```

---

## 总结

### NewPipe 方式优势
1. ✅ **无配额限制** - 可无限使用
2. ✅ **直接播放** - 获取真实流 URL
3. ✅ **隐私保护** - 不发送用户数据
4. ✅ **多客户端** - 自动故障转移
5. ✅ **免费** - 无需 API Key

### 限制和风险
1. ⚠️ **法律风险** - 可能违反 ToS
2. ⚠️ **稳定性** - 依赖内部 API
3. ⚠️ **维护成本** - 需要跟进 API 变化

### 推荐使用场景
- ✅ 个人音乐播放器
- ✅ 学习和研究项目
- ✅ 隐私敏感应用
- ❌ 商业应用（使用官方 API）

---

**最终建议**: 

对于 **音乐播放器** 项目，**NewPipe 方式是最佳选择**，因为：
1. 需要直接播放功能
2. 高频使用场景
3. 个人/学习项目
4. 多平台聚合需求

但要做好以下准备：
- 定期更新 NewPipeExtractor 库
- 实现降级方案（Invidious 等备用源）
- 添加完善的错误处理
- 遵守法律和道德规范
