process.env.GLOBAL_AGENT_HTTP_PROXY = 'http://127.0.0.1:7890';
try {
  require('global-agent').bootstrap();
  console.log('global-agent bootstrapped');
} catch (e) {
  console.error('global-agent bootstrap error', e && e.message ? e.message : e);
}

const https = require('https');
https.get('https://www.youtube.com', res => {
  console.log('status', res.statusCode);
  res.resume();
}).on('error', e => {
  console.error('err', e.message);
});
