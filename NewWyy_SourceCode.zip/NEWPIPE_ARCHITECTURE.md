# NewPipe 连接方式 - 架构图

## 整体架构

```
┌─────────────────────────────────────────────────────────────────┐
│                          用户界面 (React)                          │
│                         App.tsx / Player.tsx                      │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│                    前端服务层 (TypeScript)                         │
│                      services/geminiService.ts                    │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │  NewPipe 风格实现                                          │   │
│  │  • 多客户端配置 (WEB/ANDROID/IOS/TV)                       │   │
│  │  • 自动重试和故障转移                                       │   │
│  │  • 直接调用 InnerTube API                                  │   │
│  │  • 音频流智能选择 (opus > m4a)                             │   │
│  └──────────────────────────────────────────────────────────┘   │
└────────────┬───────────────────────────────┬────────────────────┘
             │                               │
             ▼                               ▼
┌────────────────────────────┐  ┌──────────────────────────────┐
│   Web 端 (CapacitorHttp)    │  │  Android 端 (Native Plugin)   │
│                            │  │                              │
│  直接 HTTP 请求到           │  │  NewPipeExtractorPlugin.kt   │
│  YouTube InnerTube API     │  │  • NewPipeExtractor 库       │
└────────────┬───────────────┘  │  • 自定义 Downloader          │
             │                  │  • ExoPlayer 集成            │
             │                  └────────────┬─────────────────┘
             │                               │
             └───────────────┬───────────────┘
                             ▼
        ┌─────────────────────────────────────────┐
        │    YouTube InnerTube API (内部)          │
        │  https://www.youtube.com/youtubei/v1/   │
        │                                         │
        │  • /search    - 搜索视频                 │
        │  • /player    - 获取播放信息             │
        │  • /browse    - 浏览频道                 │
        │  • /next      - 获取相关视频             │
        └─────────────────────────────────────────┘
```

---

## 请求流程详解

### 1. 搜索流程

```
用户输入 "周杰伦"
     │
     ▼
ClientSideService.searchMusic()
     │
     ├──► searchNewPipe() ────────┐
     │                            │
     ├──► searchNetease() ───┐    │
     │                       │    │
     └──► searchBilibili()   │    │
                             │    │
                    并行执行  │    │
                             │    │
                             ▼    ▼
                    ┌─────────────────────────┐
                    │  youtubeRequest()        │
                    │  [NewPipe 风格]          │
                    │                         │
                    │  1. 尝试 WEB 客户端      │
                    │     ↓ 失败？            │
                    │  2. 切换到 ANDROID       │
                    │     ↓ 失败？            │
                    │  3. 切换到 IOS           │
                    └────────┬────────────────┘
                             │
                             ▼
                    POST /youtubei/v1/search
                    Headers:
                      User-Agent: (客户端特定)
                      Origin: https://www.youtube.com
                      Referer: https://www.youtube.com/
                    Body:
                      context: { client: {...} }
                      query: "周杰伦"
                      params: "EgIQAQ%3D%3D"
                             │
                             ▼
                    ┌─────────────────────────┐
                    │  YouTube 响应           │
                    │                         │
                    │  • 视频列表             │
                    │  • 标题、作者           │
                    │  • 缩略图               │
                    │  • 时长                 │
                    └────────┬────────────────┘
                             │
                             ▼
                    解析并返回 Song[]
                             │
                             ▼
                    onProgress(songs) 回调
```

### 2. 播放流程

```
用户点击播放
     │
     ▼
ClientSideService.getSongDetails(song)
     │
     ▼
根据 song.source 选择平台
     │
     ├──► YOUTUBE: NewPipe 方式
     │      │
     │      ▼
     │   youtubeRequest('/player', CLIENTS.ANDROID)
     │      │
     │      ▼
     │   POST /youtubei/v1/player
     │   Body:
     │     context: { client: { clientName: "ANDROID" } }
     │     videoId: "xxxxx"
     │     contentCheckOk: true
     │     racyCheckOk: true
     │      │
     │      ▼
     │   ┌────────────────────────────────────┐
     │   │  YouTube 响应                       │
     │   │                                    │
     │   │  streamingData: {                 │
     │   │    adaptiveFormats: [             │
     │   │      { mimeType: "audio/webm",    │
     │   │        url: "https://...",        │
     │   │        bitrate: 160000 },         │
     │   │      { mimeType: "audio/mp4",     │
     │   │        url: "https://...",        │
     │   │        bitrate: 128000 }          │
     │   │    ]                              │
     │   │  }                                │
     │   └────────────────────────────────────┘
     │      │
     │      ▼
     │   选择最佳音频流
     │   优先级: opus > m4a > webm
     │      │
     │      ▼
     │   返回 { url, coverUrl }
     │
     ├──► NETEASE: 网易云 API
     │
     └──► BILIBILI: B站 API
```

### 3. Android 原生流程

```
调用 NewPipeExtractor.getStreamUrl(videoId)
     │
     ▼
NewPipeExtractorPlugin.kt
     │
     ▼
GlobalScope.launch(Dispatchers.Default)
     │
     ▼
getYouTubeStreamUrl(id, quality)
     │
     ▼
val url = "https://www.youtube.com/watch?v=$id"
val streamInfo = StreamInfo.getInfo(ServiceList.YouTube, url)
     │
     ▼
NewPipeExtractor 库
     │
     ├──► 1. 获取网页 HTML
     │    └──► AndroidDownloader (自定义)
     │         └──► 模拟浏览器请求头
     │              • User-Agent
     │              • Accept-Language
     │              • DNT: 1
     │
     ├──► 2. 解析 HTML 提取 ytInitialPlayerResponse
     │
     ├──► 3. 解析 StreamingData
     │
     ├──► 4. 处理签名和加密参数
     │
     └──► 5. 返回 StreamInfo
          • audioStreams: List<AudioStream>
          • videoStreams: List<VideoStream>
          • 元数据 (标题、作者等)
     │
     ▼
选择最佳音频流
val bestAudio = audioStreams.maxByOrNull { it.averageBitrate }
     │
     ▼
返回 JSONObject {
  url: "https://rr1---sn-xxxx.googlevideo.com/...",
  quality: "160 kbps",
  format: "opus"
}
```

---

## 多客户端切换机制

```
┌─────────────────────────────────────────────────────────────┐
│                     youtubeRequest()                        │
│                                                             │
│  尝试客户端: [WEB, ANDROID, IOS, TVHTML5_EMBEDDED]           │
│  重试次数: 0                                                 │
└──────────────────────────┬──────────────────────────────────┘
                           │
                           ▼
              ┌────────────────────────┐
              │   尝试 WEB 客户端       │
              │   clientVersion: 2.x    │
              └────────┬───────────────┘
                       │
                ┌──────┴──────┐
                │   成功？     │
                └──────┬──────┘
                NO ↓   │ YES
                   │   └──────────────► 返回结果
                   ▼
              ┌────────────────────────┐
              │  尝试 ANDROID 客户端    │
              │  clientVersion: 19.x    │
              │  androidSdkVersion: 33  │
              └────────┬───────────────┘
                       │
                ┌──────┴──────┐
                │   成功？     │
                └──────┬──────┘
                NO ↓   │ YES
                   │   └──────────────► 返回结果
                   ▼
              ┌────────────────────────┐
              │   尝试 IOS 客户端       │
              │   deviceModel: iPhone   │
              └────────┬───────────────┘
                       │
                ┌──────┴──────┐
                │   成功？     │
                └──────┬──────┘
                NO ↓   │ YES
                   │   └──────────────► 返回结果
                   ▼
              ┌────────────────────────┐
              │ 尝试 TVHTML5_EMBEDDED   │
              │ (嵌入式播放器)          │
              └────────┬───────────────┘
                       │
                ┌──────┴──────┐
                │   成功？     │
                └──────┬──────┘
                NO ↓   │ YES
                   │   └──────────────► 返回结果
                   ▼
              抛出错误: "All clients failed"
```

---

## 数据流图

```
┌──────────┐
│  用户界面  │
└─────┬────┘
      │ 1. 点击"播放"
      ▼
┌──────────────────────────┐
│  ClientSideService        │
│  getSongDetails(song)    │
└─────┬────────────────────┘
      │ 2. 检测平台
      ▼
┌──────────────────────────┐
│  youtubeRequest()        │
│  • 选择客户端 (ANDROID)   │
│  • 构建请求头和参数       │
└─────┬────────────────────┘
      │ 3. HTTP POST
      ▼
┌──────────────────────────────────────┐
│  YouTube InnerTube API               │
│  POST /youtubei/v1/player            │
│                                      │
│  请求:                                │
│  {                                   │
│    context: {                        │
│      client: { clientName: "ANDROID" }│
│    },                                │
│    videoId: "xxxxx"                  │
│  }                                   │
└─────┬────────────────────────────────┘
      │ 4. JSON 响应
      ▼
┌──────────────────────────────────────┐
│  响应数据                             │
│  {                                   │
│    streamingData: {                  │
│      adaptiveFormats: [              │
│        {                             │
│          mimeType: "audio/webm",     │
│          url: "https://...",         │
│          bitrate: 160000             │
│        }                             │
│      ]                               │
│    },                                │
│    videoDetails: {                   │
│      title: "歌曲名",                 │
│      thumbnail: {...}                │
│    }                                 │
│  }                                   │
└─────┬────────────────────────────────┘
      │ 5. 解析和筛选
      ▼
┌──────────────────────────┐
│  选择最佳音频流           │
│  • 过滤 audio 格式        │
│  • 按比特率排序           │
│  • 优先 opus > m4a        │
└─────┬────────────────────┘
      │ 6. 返回结果
      ▼
┌──────────────────────────┐
│  SongPlayDetails         │
│  {                       │
│    url: "https://...",   │
│    coverUrl: "...",      │
│    lyric?: "..."         │
│  }                       │
└─────┬────────────────────┘
      │ 7. 传递给播放器
      ▼
┌──────────┐
│  Player   │
│  播放音频  │
└──────────┘
```

---

## 关键技术点

### 1. 客户端模拟

```typescript
// 不同客户端有不同的特性
const CLIENTS = {
  WEB: {
    // 搜索最稳定
    优势: "搜索结果最完整",
    劣势: "某些视频可能受限"
  },
  ANDROID: {
    // 播放最稳定
    优势: "流 URL 最可靠, 很少失败",
    劣势: "需要正确的 SDK 版本"
  },
  IOS: {
    // 备用选择
    优势: "某些地区限制较少",
    劣势: "需要正确的设备型号"
  },
  TVHTML5_EMBEDDED: {
    // 嵌入式播放器
    优势: "绕过某些限制",
    劣势: "功能相对受限"
  }
};
```

### 2. 请求头伪装

```typescript
headers: {
  // 核心头部 - 模拟真实客户端
  'User-Agent': client.context.client.userAgent,
  'Content-Type': 'application/json',
  
  // 语言和地区
  'Accept-Language': 'en-US,en;q=0.9',
  
  // 来源标识 - 重要！
  'Origin': 'https://www.youtube.com',
  'Referer': 'https://www.youtube.com/',
  
  // 隐私保护
  'DNT': '1',  // Do Not Track
  
  // 通用接受头
  'Accept': '*/*'
}
```

### 3. 音频流选择策略

```typescript
// NewPipe 的流选择逻辑
function selectBestAudioStream(formats) {
  // 1. 过滤出音频流
  const audioFormats = formats.filter(f => 
    f.mimeType?.includes('audio')
  );
  
  // 2. 按比特率排序 (高到低)
  audioFormats.sort((a, b) => 
    (b.bitrate || 0) - (a.bitrate || 0)
  );
  
  // 3. 格式优先级: opus > m4a > webm
  const opus = audioFormats.find(f => f.mimeType.includes('opus'));
  const m4a = audioFormats.find(f => f.mimeType.includes('mp4'));
  
  // 4. 返回最佳选择
  return opus || m4a || audioFormats[0];
}
```

---

## 性能优化点

### 1. 并行搜索

```typescript
// 同时搜索多个平台
async searchMusic(query: string, onProgress: Function) {
  // 不等待，立即返回
  this.searchNewPipe(query).then(onProgress);
  this.searchNetease(query).then(onProgress);
  this.searchBilibili(query).then(onProgress);
}
```

### 2. 超时控制

```typescript
const response = await CapacitorHttp.post({
  url: '...',
  connectTimeout: 10000,  // 连接超时 10秒
  readTimeout: 15000      // 读取超时 15秒
});
```

### 3. 结果缓存

```typescript
private cache = new Map<string, Song[]>();

async searchMusic(query: string) {
  if (this.cache.has(query)) {
    return this.cache.get(query);
  }
  
  const results = await this.performSearch(query);
  this.cache.set(query, results);
  return results;
}
```

---

## 错误处理流程

```
请求失败
     │
     ▼
┌─────────────────┐
│  检查错误类型    │
└────┬────────────┘
     │
     ├──► 网络错误 (ETIMEDOUT, ECONNREFUSED)
     │    └──► 重试当前客户端 (最多 1 次)
     │         └──► 仍失败？切换到下一个客户端
     │
     ├──► 4xx 错误 (403, 429)
     │    └──► 立即切换到下一个客户端
     │         └──► 429: 额外延迟 2 秒
     │
     ├──► 5xx 错误 (503)
     │    └──► 延迟 1 秒后重试当前客户端
     │         └──► 仍失败？切换到下一个客户端
     │
     └──► 解析错误
          └──► 切换到下一个客户端
               └──► 所有客户端都失败？
                    └──► 返回错误给用户
```

---

## 总结

NewPipe 连接方式的核心优势在于：

1. **直接性** - 直接调用 InnerTube API，无中间层
2. **灵活性** - 多客户端自动切换，适应各种情况
3. **可靠性** - 多重故障转移机制
4. **性能** - 并行请求，快速响应
5. **隐私** - 不发送用户数据，模拟标准浏览器

这使得它非常适合音乐播放器等需要直接访问媒体流的应用。
