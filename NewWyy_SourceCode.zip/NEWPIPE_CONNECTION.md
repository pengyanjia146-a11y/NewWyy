# NewPipe 风格的连接实现

## NewPipe 的核心连接方式

NewPipe 是一个轻量级的 YouTube 客户端，它不使用 YouTube 官方 API，而是通过以下方式获取数据：

### 1. **使用 InnerTube API（YouTube 内部 API）**
```
YouTube 官方客户端（Web/Android/iOS）使用的内部 API
端点：https://www.youtube.com/youtubei/v1/
不需要 OAuth，但需要模拟真实客户端
```

### 2. **多客户端策略（Fallback）**
NewPipe 支持多种客户端模拟，当一个失败时切换到另一个：
- **ANDROID** - 最稳定，支持大部分功能
- **IOS** - 备用选择，某些地区限制较少
- **WEB** - 搜索时最稳定
- **TVHTML5_EMBEDDED** - 嵌入式播放器，绕过某些限制

### 3. **关键请求头模拟**
```http
User-Agent: com.google.android.youtube/19.09.37 (模拟真实 Android 客户端)
Accept-Language: en-US,en;q=0.9
Origin: https://www.youtube.com
Referer: https://www.youtube.com/
DNT: 1 (Do Not Track)
```

### 4. **NewPipeExtractor 库**
- **Java/Kotlin 库**：用于提取 YouTube、SoundCloud、PeerTube 等平台数据
- **GitHub**: https://github.com/TeamNewPipe/NewPipeExtractor
- **特点**：
  - 解析网页 HTML
  - 使用 InnerTube API
  - 自动处理签名和加密参数
  - 支持多平台

---

## 我们的实现

### **1. Android 原生插件（Kotlin）**

文件：`android/newpipe-plugin/src/main/java/com/unistream/newpipe/NewPipeExtractorPlugin.kt`

```kotlin
// 依赖
implementation("com.github.TeamNewPipe:NewPipeExtractor:0.23.2")

// 初始化
NewPipe.init(AndroidDownloader(), Localization.DEFAULT)

// 使用
val streamInfo = StreamInfo.getInfo(ServiceList.YouTube, url)
val audioStreams = streamInfo.audioStreams
val bestAudio = audioStreams.maxByOrNull { it.averageBitrate }
```

**特点**：
- ✅ 使用官方 NewPipeExtractor 库
- ✅ 自定义 Downloader，模拟浏览器行为
- ✅ 自动解析音频流 URL
- ✅ 支持 YouTube、Bilibili、网易云

### **2. 前端实现（TypeScript）**

文件：`services/geminiService.ts`

```typescript
// 多客户端配置
const CLIENTS = { WEB, ANDROID, IOS, TVHTML5_EMBEDDED }

// 带重试的请求方法
private async youtubeRequest(endpoint, client, data, retryCount = 0) {
  try {
    return await CapacitorHttp.post({
      url: `${YOUTUBEI_V1_URL}${endpoint}?key=${API_KEY}`,
      headers: { /* 模拟真实客户端 */ },
      data: { ...client, ...data }
    });
  } catch (e) {
    // 自动切换到下一个客户端重试
    if (retryCount < maxRetries) {
      return this.youtubeRequest(endpoint, nextClient, data, retryCount + 1);
    }
    throw e;
  }
}
```

**特点**：
- ✅ 多客户端自动切换
- ✅ 重试机制
- ✅ 完整的请求头模拟
- ✅ 优先选择高质量音频流（opus > m4a）

### **3. 后端实现（Node.js）**

文件：`server.js` / `server.cjs`

```javascript
// 使用 youtubei.js 库（NewPipe 的 JS 版本）
const { Innertube } = require('youtubei.js');

const yt = await Innertube.create({
  cache: new UniversalCache(false),
  generate_session_locally: true
});

// 搜索
const results = await yt.search(query, { type: 'video' });

// 获取播放信息
const info = await yt.getBasicInfo(videoId, 'ANDROID');
const audioFormat = info.streaming_data.adaptive_formats
  .filter(f => f.mime_type.includes('audio'))
  .sort((a, b) => b.bitrate - a.bitrate)[0];
```

**特点**：
- ✅ 使用 youtubei.js（与 NewPipe 相同的原理）
- ✅ 支持代理配置
- ✅ 自动会话管理
- ✅ 直接重定向到 Google CDN

---

## NewPipe 连接方式的优势

### ✅ **无需 API Key**
- 不依赖官方 API 配额
- 无需申请 API 密钥
- 避免速率限制

### ✅ **高可用性**
- 多客户端故障转移
- 自动重试机制
- 绕过地区限制

### ✅ **轻量级**
- 不需要 OAuth 认证
- 最小化网络请求
- 直接获取流 URL

### ✅ **隐私保护**
- 不发送用户数据到 Google
- 不使用 Cookies（可选）
- 不记录观看历史

---

## 使用示例

### **前端调用**
```typescript
import { ClientSideService } from './services/geminiService';

const service = new ClientSideService();

// 搜索（使用 NewPipe 风格）
service.searchMusic('歌曲名称', (songs) => {
  console.log('找到歌曲:', songs);
});

// 获取播放 URL（自动多客户端切换）
const details = await service.getSongDetails(song, 'high');
console.log('播放地址:', details.url);
```

### **原生插件调用**
```typescript
import newpipe from './services/newpipePlugin';

// 获取视频信息
const info = await newpipe.getInfo('VIDEO_ID');
console.log(info.title, info.uploader);

// 获取流地址
const stream = await newpipe.getStreamUrl('VIDEO_ID');
console.log(stream.url);
```

---

## 故障处理

### **客户端切换优先级**
```
搜索：WEB → ANDROID → IOS
播放：ANDROID → IOS → TVHTML5_EMBEDDED → WEB
```

### **常见问题处理**

1. **"Video unavailable"**
   - 自动切换到下一个客户端
   - 尝试使用嵌入式播放器

2. **429 Too Many Requests**
   - 减慢请求速度
   - 使用不同的客户端标识

3. **签名验证失败**
   - NewPipeExtractor 自动处理
   - 更新库版本

---

## 与官方 API 的对比

| 特性 | NewPipe 方式 | YouTube Data API v3 |
|------|-------------|-------------------|
| API Key | ❌ 不需要 | ✅ 需要 |
| 配额限制 | ✅ 无限制 | ❌ 每天 10,000 |
| 播放 URL | ✅ 直接获取 | ❌ 需额外请求 |
| 地区限制 | ✅ 可绕过 | ❌ 严格 |
| 稳定性 | ⚠️ 依赖内部 API | ✅ 官方支持 |
| 法律风险 | ⚠️ 灰色地带 | ✅ 合规 |

---

## 合规性提醒

⚠️ **重要声明**：

NewPipe 的连接方式可能违反 YouTube 的服务条款。使用此方法：

1. **教育和研究目的** - 可以接受
2. **个人非商业使用** - 风险较低
3. **商业应用** - **不推荐**，可能面临法律风险

**建议**：
- 不要大规模爬取数据
- 遵守平台的 robots.txt
- 考虑使用官方 API（如果适用）
- 仅用于学习和个人项目

---

## 更新日志

- **2024-01-11**: 添加多客户端支持（IOS, TVHTML5）
- **2024-01-11**: 实现自动重试和故障转移
- **2024-01-11**: 完整的 NewPipeExtractor Kotlin 实现
- **2024-01-11**: 改进请求头，更真实地模拟浏览器

---

## 参考资料

- [NewPipe GitHub](https://github.com/TeamNewPipe/NewPipe)
- [NewPipeExtractor](https://github.com/TeamNewPipe/NewPipeExtractor)
- [youtubei.js](https://github.com/LuanRT/YouTube.js)
- [InnerTube API 逆向工程](https://github.com/iv-org/invidious)
