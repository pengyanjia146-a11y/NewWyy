# NewPipe 风格连接 - 快速开始

## 📦 已实现的功能

✅ **Android 原生 NewPipeExtractor 集成**  
✅ **前端多客户端自动切换**  
✅ **搜索、播放 URL 获取**  
✅ **自动重试和故障转移**

---

## 🚀 快速开始

### 1. 构建 Android 插件

```bash
cd android/newpipe-plugin
./gradlew build
```

### 2. 前端使用

```typescript
import { ClientSideService } from './services/geminiService';

const service = new ClientSideService();

// 搜索音乐（NewPipe 风格）
await service.searchMusic('周杰伦', (songs) => {
  console.log('找到歌曲:', songs);
  // songs 包含 YouTube、网易云、Bilibili 的结果
});

// 获取播放 URL
const song = songs[0];
const details = await service.getSongDetails(song);
console.log('播放地址:', details.url);
```

### 3. 测试连接

```bash
# 运行测试脚本（确保已安装依赖）
npm run test:newpipe
```

或在前端代码中：

```typescript
import { runNewPipeTests } from './tests/test_newpipe_connection';

// 运行完整测试
await runNewPipeTests();
```

---

## 🔧 配置说明

### Android 插件配置

文件：`android/newpipe-plugin/build.gradle.kts`

```kotlin
dependencies {
    // NewPipeExtractor - 核心库
    implementation("com.github.TeamNewPipe:NewPipeExtractor:v0.23.2")
    
    // ExoPlayer - 用于播放
    implementation("com.google.android.exoplayer:exoplayer:2.20.0")
}
```

### 前端配置

文件：`services/geminiService.ts`

```typescript
// 多客户端配置（NewPipe 风格）
const CLIENTS = {
    WEB: { /* 用于搜索 */ },
    ANDROID: { /* 用于播放，最稳定 */ },
    IOS: { /* 备用选择 */ },
    TVHTML5_EMBEDDED: { /* 嵌入式播放器 */ }
};
```

---

## 💡 使用示例

### 示例 1: 搜索并播放

```typescript
const service = new ClientSideService();

// 搜索
await service.searchMusic('稻香', async (songs) => {
  if (songs.length > 0) {
    const song = songs[0];
    console.log(`找到: ${song.title} - ${song.artist}`);
    
    // 获取播放 URL
    const details = await service.getSongDetails(song, 'high');
    
    if (details.url) {
      console.log('可以播放:', details.url);
      // 传递给播放器...
    }
  }
});
```

### 示例 2: 使用原生插件（Android）

```typescript
import newpipe from './services/newpipePlugin';

// 获取视频信息
const info = await newpipe.getInfo('VIDEO_ID');
console.log(info.title);        // 视频标题
console.log(info.uploader);     // 上传者
console.log(info.duration);     // 时长（秒）

// 获取最佳音频流
const stream = await newpipe.getStreamUrl('VIDEO_ID', 'high');
console.log(stream.url);        // 播放 URL
console.log(stream.quality);    // 质量信息
```

### 示例 3: 手动客户端切换

```typescript
// 在 geminiService.ts 中
private async youtubeRequest(endpoint: string, client: any, data: any) {
  try {
    // 第一次尝试
    return await this.makeRequest(endpoint, CLIENTS.ANDROID, data);
  } catch (e) {
    // 自动切换到 IOS
    return await this.makeRequest(endpoint, CLIENTS.IOS, data);
  }
}
```

---

## 🧪 测试功能

运行测试脚本验证连接：

```bash
# 测试 YouTube API 连接
npm run test:newpipe:connection

# 测试搜索功能
npm run test:newpipe:search

# 测试播放 URL 获取
npm run test:newpipe:playback

# 完整测试
npm run test:newpipe:all
```

或在浏览器控制台：

```javascript
// 导入测试模块
import tests from './tests/test_newpipe_connection';

// 测试连接
await tests.testConnection();

// 测试搜索
const videoId = await tests.testSearch('music');

// 测试获取播放 URL
await tests.testGetStreamUrl(videoId);

// 完整测试流程
await tests.runNewPipeTests();
```

---

## 🔍 调试技巧

### 1. 启用详细日志

```typescript
// 在 geminiService.ts 中
private log(msg: string) {
    console.log(`[NewPipe] ${msg}`);
}
```

### 2. 检查客户端切换

```typescript
// 添加到 youtubeRequest 方法
console.log(`使用客户端: ${client.context.client.clientName}`);
```

### 3. 查看原始响应

```typescript
const response = await CapacitorHttp.post({...});
console.log('原始响应:', JSON.stringify(response.data).substring(0, 500));
```

---

## ⚠️ 常见问题

### Q: "No streaming data" 错误

**原因**: 视频受地区限制或客户端不支持  
**解决**: 自动切换到下一个客户端（已实现）

```typescript
// 客户端切换顺序
播放: ANDROID → IOS → TVHTML5_EMBEDDED → WEB
```

### Q: 429 Too Many Requests

**原因**: 请求过于频繁  
**解决**: 
- 减慢请求速度
- 使用不同的客户端标识
- 添加延迟

```typescript
await new Promise(resolve => setTimeout(resolve, 1000));
```

### Q: Android 插件编译失败

**原因**: 依赖冲突或版本不匹配  
**解决**:
```kotlin
// 在 build.gradle.kts 中排除冲突
implementation("com.github.TeamNewPipe:NewPipeExtractor:v0.23.2") {
    exclude(group = "org.mozilla", module = "rhino")
}
```

### Q: 视频无法播放

**原因**: URL 签名过期或格式不支持  
**解决**:
- URL 有效期约 6 小时，需要重新获取
- 确保播放器支持 HLS/DASH 格式

---

## 📊 性能优化

### 1. 缓存搜索结果

```typescript
private searchCache = new Map<string, Song[]>();

async searchMusic(query: string, onProgress: Function) {
  // 检查缓存
  if (this.searchCache.has(query)) {
    onProgress(this.searchCache.get(query));
    return;
  }
  
  // 执行搜索...
  this.searchCache.set(query, results);
}
```

### 2. 并行请求

```typescript
// 同时搜索多个平台
const [youtubeResults, neteaseResults, biliResults] = await Promise.all([
  this.searchNewPipe(query),
  this.searchNetease(query),
  this.searchBilibili(query)
]);
```

### 3. 超时控制

```typescript
const response = await CapacitorHttp.post({
  url: '...',
  connectTimeout: 10000,  // 10秒超时
  readTimeout: 15000      // 15秒读取超时
});
```

---

## 🔐 隐私和安全

### NewPipe 的隐私优势

- ✅ 不发送用户数据到 Google
- ✅ 不使用 Cookies（可选）
- ✅ 不跟踪观看历史
- ✅ 直接连接到视频源

### 最佳实践

```typescript
// 不发送用户标识
headers: {
  'DNT': '1',  // Do Not Track
  // 不包含用户特定的 Cookie
}

// 使用通用的 User-Agent
userAgent: 'Mozilla/5.0 (通用浏览器标识)'
```

---

## 📚 更多资源

- [完整文档](./NEWPIPE_CONNECTION.md)
- [NewPipe GitHub](https://github.com/TeamNewPipe/NewPipe)
- [NewPipeExtractor API](https://teamnewpipe.github.io/documentation/)
- [YouTube InnerTube API](https://github.com/iv-org/invidious/blob/master/docs/API.md)

---

## 🤝 贡献

发现问题或有改进建议？欢迎提交 Issue 或 PR！

**改进方向**：
- 添加更多平台支持（SoundCloud、PeerTube）
- 改进客户端选择算法
- 添加自动代理切换
- 实现智能缓存策略

---

## 📄 许可证

⚠️ **法律提醒**: 此实现仅供学习和研究使用。NewPipe 的连接方式可能违反某些平台的服务条款，请谨慎使用，不要用于商业目的。

使用此代码，您承认理解相关风险。
