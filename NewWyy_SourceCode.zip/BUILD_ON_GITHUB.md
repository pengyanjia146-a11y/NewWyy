# 在 GitHub Actions 上构建 APK

下面说明如何使用我们刚添加的 GitHub Actions 工作流自动构建 APK（unsigned 或 signed）。

## 触发方式
- Push 到 `main` 或 `master` 分支时自动触发
- 在 GitHub 页面手动触发 `Actions -> Build Android APK -> Run workflow`

## 可选签名（Release 签名）
如果你想要生成已签名的 APK，需要在仓库 Secrets 中添加以下项：

- `KEYSTORE_BASE64`：Keystore 文件（.jks）经过 base64 编码后的字符串
- `KEYSTORE_PASS`：Keystore 密码
- `KEY_ALIAS`：密钥别名
- `KEY_PASSWORD`：密钥密码

生成 base64 示例（本地）：

```bash
base64 -w 0 my-release-key.jks > keystore.b64.txt
# 将 keystore.b64.txt 的内容复制到 GitHub Secret `KEYSTORE_BASE64`
```

> 工作流会在构建后解码 `KEYSTORE_BASE64` 为 `release.keystore` 并执行 `zipalign` + `apksigner` 来签名 APK。

## 构建产物
- 未签名的 APK（artifact 名称：`app-release-unsigned`）
- 如果提供签名信息：已签名的 APK（artifact 名称：`app-release-signed`）

## 在本地手动构建（快速）
确保你已经安装好 Android SDK、Java 17，并在项目根目录运行：

```bash
# 构建 release APK（使用本地 gradle 包装器）
cd android
./gradlew assembleRelease
# 输出: android/app/build/outputs/apk/release/
```

如果要本地签名：

```bash
# 对未签名的 APK 进行 zipalign 和签名（示例）
# 假设 build-tools 在 $ANDROID_HOME/build-tools/33.0.2
APK_IN=android/app/build/outputs/apk/release/app-release-unsigned.apk
BUILD_TOOLS="$ANDROID_HOME/build-tools/33.0.2"
$BUILD_TOOLS/zipalign -v -p 4 "$APK_IN" "aligned.apk"
$BUILD_TOOLS/apksigner sign --ks my-release-key.jks --ks-pass pass:KEYSTORE_PASS --ks-key-alias KEY_ALIAS --key-pass pass:KEY_PASSWORD --out "app-release-signed.apk" "aligned.apk"
```

## 常见问题
- 如果工作流在安装 SDK 步骤失败，请在 Actions 日志中检查 `sdkmanager` 输出。
- 如果找不到 `app-release-unsigned.apk`，确认模块路径是否为 `android/app`，或在 `android/` 子目录中查看 `build/outputs`。


如果你需要，我可以：
- 把工作流调整为调试构建或生成不同构建变体；
- 帮你把 `KEYSTORE_BASE64` 自动生成脚本加入仓库（仅本地运行）；
- 在 CI 中实现自动上传到 GitHub Release 或 Play Store（需要权限）。
