const axios = require('axios');
const qs = require('querystring');

async function run() {
  try {
    const keyword = process.argv[2] || '周杰伦';
    console.log('Searching Netease for:', keyword);
    const searchData = qs.stringify({ s: keyword, type: 1, offset: 0, limit: 5, total: true });
    const searchRes = await axios.post('https://music.163.com/api/cloudsearch/pc', searchData, {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Referer': 'https://music.163.com/',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'
      },
      timeout: 10000
    });

    const songs = searchRes.data?.result?.songs || [];
    if (!songs.length) {
      console.log('No songs found');
      return;
    }

    const first = songs[0];
    console.log('Found song:', first.name, 'id=', first.id);

    // Try to get playable URL
    const ids = `[${first.id}]`;
    const urlData = qs.stringify({ ids, br: 320000 });
    const urlRes = await axios.post('https://music.163.com/api/song/enhance/player/url', urlData, {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Referer': 'https://music.163.com/',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'
      },
      timeout: 10000
    });

    const realUrl = urlRes.data?.data?.[0]?.url;
    if (realUrl) {
      console.log('Playable URL resolved:', realUrl);
    } else {
      console.log('No playable URL returned (可能需要登录或版权限制)');
      console.log('Raw response:', JSON.stringify(urlRes.data));
    }
  } catch (e) {
    console.error('Error:', e.message || e);
  }
}

run();
