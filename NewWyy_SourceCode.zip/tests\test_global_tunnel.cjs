try {
  const gt = require('global-tunnel-ng');
  gt.initialize({ host: '127.0.0.1', port: 7890, protocol: 'http', sockets: 50 });
  console.log('global-tunnel-ng initialized');
} catch (e) {
  console.error('global-tunnel-ng init error', e && e.message ? e.message : e);
}

const https = require('https');
https.get('https://www.youtube.com', res => {
  console.log('status', res.statusCode);
  res.resume();
}).on('error', e => {
  console.error('err', e.message);
});
