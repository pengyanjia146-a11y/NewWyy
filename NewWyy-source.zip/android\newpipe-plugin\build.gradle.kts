plugins {
    id("com.android.library")
    kotlin("android") version "1.9.10"
}

android {
    namespace = "com.unistream.newpipe"
    compileSdk = 33

    defaultConfig {
        minSdk = 21
        targetSdk = 33
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

repositories {
    mavenCentral()
    maven("https://jitpack.io")
    google()
}

dependencies {
    implementation("org.jetbrains.kotlin:kotlin-stdlib")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
    
    // NewPipeExtractor - 使用更新的版本以支持最新的 YouTube 变化
    implementation("com.github.TeamNewPipe:NewPipeExtractor:v0.23.2") {
        exclude(group = "org.mozilla", module = "rhino")
    }
    
    // ExoPlayer for native playback
    implementation("com.google.android.exoplayer:exoplayer:2.20.0")
    
    // Capacitor Android runtime
    implementation("com.getcapacitor:capacitor-android:5.7.0")
    
    // JSON 处理（NewPipeExtractor 依赖）
    implementation("com.grack:nanojson:1.7")
}
