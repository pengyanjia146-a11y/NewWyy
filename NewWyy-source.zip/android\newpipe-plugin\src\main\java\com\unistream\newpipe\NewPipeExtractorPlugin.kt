package com.unistream.newpipe

import android.content.Context
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.annotation.CapacitorPlugin
import com.getcapacitor.annotation.PluginMethod
import org.json.JSONObject
import org.json.JSONArray
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import java.net.URL
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.AudioStream
import org.schabi.newpipe.extractor.localization.Localization
import org.schabi.newpipe.extractor.services.youtube.extractors.YoutubeStreamExtractor
import org.schabi.newpipe.extractor.downloader.Downloader
import org.schabi.newpipe.extractor.downloader.Request
import org.schabi.newpipe.extractor.downloader.Response
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException
import java.io.IOException
import java.net.HttpURLConnection

/**
 * NewPipeExtractor Capacitor Plugin
 * 提供 YouTube、Bilibili、网易云的原生解析与 ExoPlayer 播放能力
 * Note: NewPipeExtractor 导入需要在 module build.gradle 中正确配置依赖
 */
@CapacitorPlugin(name = "NewPipeExtractor")
class NewPipeExtractorPlugin : Plugin() {

    private var exoPlayer: ExoPlayer? = null
    
    init {
        // 初始化 NewPipe Extractor
        try {
            NewPipe.init(AndroidDownloader(), Localization.DEFAULT)
        } catch (e: Exception) {
            android.util.Log.e("NewPipeExtractor", "Failed to initialize: ${e.message}")
        }
    }
    
    /**
     * NewPipe 风格的下载器 - 模拟浏览器行为
     */
    private class AndroidDownloader : Downloader() {
        private val userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        
        @Throws(IOException::class, ReCaptchaException::class)
        override fun execute(request: Request): Response {
            val url = URL(request.url())
            val connection = url.openConnection() as HttpURLConnection
            
            connection.requestMethod = request.httpMethod()
            connection.connectTimeout = 30000
            connection.readTimeout = 30000
            
            // 添加 NewPipe 风格的请求头
            connection.setRequestProperty("User-Agent", userAgent)
            connection.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
            connection.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
            connection.setRequestProperty("DNT", "1")
            
            // 添加自定义头部
            request.headers()?.forEach { (key, values) ->
                values.forEach { value ->
                    connection.setRequestProperty(key, value)
                }
            }
            
            // 发送请求体（如果有）
            request.dataToSend()?.let { data ->
                connection.doOutput = true
                connection.outputStream.use { it.write(data) }
            }
            
            val responseCode = connection.responseCode
            val responseMessage = connection.responseMessage
            val responseHeaders = mutableMapOf<String, List<String>>()
            
            connection.headerFields?.forEach { (key, value) ->
                key?.let { responseHeaders[it] = value }
            }
            
            val responseBody = try {
                connection.inputStream.bufferedReader().use { it.readText() }
            } catch (e: IOException) {
                connection.errorStream?.bufferedReader()?.use { it.readText() } ?: ""
            }
            
            return Response(responseCode, responseMessage, responseHeaders, responseBody, connection.url?.toString())
        }
    }

    @PluginMethod
    fun getInfo(call: PluginCall) {
        val id = call.getString("id") ?: run {
            call.reject("id is required")
            return
        }
        val source = call.getString("source") ?: "YOUTUBE"

        // 在后台线程执行网络调用（避免阻塞主线程）
        GlobalScope.launch(Dispatchers.Default) {
            try {
                val result = when (source.uppercase()) {
                    "YOUTUBE" -> getYouTubeInfo(id)
                    "BILIBILI" -> getBilibiliInfo(id)
                    "NETEASE" -> getNeteaseInfo(id)
                    else -> JSONObject().apply { put("error", "Unknown source") }
                }
                call.resolve(result)
            } catch (e: Exception) {
                call.reject(e.message ?: "Failed to get info")
            }
        }
    }

    @PluginMethod
    fun getStreamUrl(call: PluginCall) {
        val id = call.getString("id") ?: run {
            call.reject("id is required")
            return
        }
        val source = call.getString("source") ?: "YOUTUBE"
        val quality = call.getString("quality") ?: "auto"

        GlobalScope.launch(Dispatchers.Default) {
            try {
                val result = when (source.uppercase()) {
                    "YOUTUBE" -> getYouTubeStreamUrl(id, quality)
                    "BILIBILI" -> getBilibiliStreamUrl(id, quality)
                    "NETEASE" -> getNeteaseStreamUrl(id, quality)
                    else -> JSONObject().apply { put("error", "Unknown source") }
                }
                call.resolve(result)
            } catch (e: Exception) {
                call.reject(e.message ?: "Failed to get stream url")
            }
        }
    }

    @PluginMethod
    fun play(call: PluginCall) {
        val url = call.getString("url") ?: run {
            call.reject("url is required")
            return
        }
        val headers = call.getObject("headers") ?: JSONObject()

        try {
            val ctx: Context? = bridge?.context
            if (ctx == null) {
                call.reject("Context not available")
                return
            }

            if (exoPlayer == null) {
                exoPlayer = ExoPlayer.Builder(ctx).build()
            }

            val mediaItem = MediaItem.Builder()
                .setUri(url)
                .build()

            exoPlayer?.apply {
                setMediaItem(mediaItem)
                prepare()
                play()
            }

            val res = JSONObject()
            res.put("status", "playing")
            res.put("url", url)
            call.resolve(res)
        } catch (e: Exception) {
            call.reject(e.message ?: "Failed to play")
        }
    }

    @PluginMethod
    fun pausePlayback(call: PluginCall) {
        try {
            exoPlayer?.pause()
            call.resolve(JSONObject().put("status", "paused"))
        } catch (e: Exception) {
            call.reject(e.message)
        }
    }

    @PluginMethod
    fun stopPlayback(call: PluginCall) {
        try {
            exoPlayer?.stop()
            call.resolve(JSONObject().put("status", "stopped"))
        } catch (e: Exception) {
            call.reject(e.message)
        }
    }

    // ==================== 具体源的实现 ====================

    private fun getYouTubeInfo(id: String): JSONObject {
        return try {
            val url = "https://www.youtube.com/watch?v=$id"
            val streamInfo = StreamInfo.getInfo(ServiceList.YouTube, url)
            
            JSONObject().apply {
                put("id", id)
                put("title", streamInfo.name)
                put("uploader", streamInfo.uploaderName)
                put("uploaderUrl", streamInfo.uploaderUrl)
                put("duration", streamInfo.duration)
                put("viewCount", streamInfo.viewCount)
                put("likeCount", streamInfo.likeCount)
                put("description", streamInfo.description?.content ?: "")
                put("thumbnailUrl", streamInfo.thumbnailUrl)
                put("source", "YOUTUBE")
                
                // 添加可用的音频流信息
                val audioStreams = JSONArray()
                streamInfo.audioStreams?.forEach { stream ->
                    audioStreams.put(JSONObject().apply {
                        put("url", stream.url)
                        put("format", stream.format?.toString() ?: "")
                        put("averageBitrate", stream.averageBitrate)
                    })
                }
                put("audioStreams", audioStreams)
            }
        } catch (e: Exception) {
            JSONObject().apply { 
                put("error", "Failed to fetch YouTube info: ${e.message}")
                put("id", id)
            }
        }
    }

    private fun getYouTubeStreamUrl(id: String, quality: String): JSONObject {
        return try {
            val url = "https://www.youtube.com/watch?v=$id"
            val streamInfo = StreamInfo.getInfo(ServiceList.YouTube, url)
            
            // 获取最佳音频流（NewPipe 风格）
            val audioStreams = streamInfo.audioStreams
            if (audioStreams.isNullOrEmpty()) {
                return JSONObject().apply { put("error", "No audio streams available") }
            }
            
            // 按比特率排序，选择最佳质量
            val bestAudio = audioStreams.maxByOrNull { it.averageBitrate }
            
            JSONObject().apply {
                put("url", bestAudio?.url ?: "")
                put("quality", "${bestAudio?.averageBitrate ?: 0} kbps")
                put("format", bestAudio?.format?.toString() ?: "")
                put("mimeType", bestAudio?.format?.mimeType ?: "")
                put("source", "YOUTUBE")
                put("id", id)
            }
        } catch (e: Exception) {
            JSONObject().apply { 
                put("error", "Failed to get YouTube stream: ${e.message}")
                put("id", id)
            }
        }
    }

    private fun getBilibiliInfo(id: String): JSONObject {
        // 直接调用 Bilibili API 获取元信息
        return try {
            val apiUrl = "https://api.bilibili.com/x/web-interface/view?bvid=$id"
            val response = URL(apiUrl).readText()
            val json = org.json.JSONObject(response)
            val data = json.optJSONObject("data") ?: JSONObject()

            JSONObject().apply {
                put("id", id)
                put("title", data.optString("title", "Unknown"))
                put("uploader", data.optJSONObject("owner")?.optString("name") ?: "Unknown")
                put("duration", data.optInt("duration", 0))
                put("source", "BILIBILI")
            }
        } catch (e: Exception) {
            JSONObject().apply { put("error", e.message) }
        }
    }

    private fun getBilibiliStreamUrl(id: String, quality: String): JSONObject {
        // 获取 Bilibili 视频流地址
        return try {
            val viewUrl = "https://api.bilibili.com/x/web-interface/view?bvid=$id"
            val viewResponse = URL(viewUrl).readText()
            val viewJson = org.json.JSONObject(viewResponse)
            val cid = viewJson.optJSONObject("data")?.optLong("cid", 0) ?: 0

            if (cid == 0L) {
                return JSONObject().apply { put("error", "CID not found") }
            }

            val playUrl = "https://api.bilibili.com/x/player/playurl?bvid=$id&cid=$cid&qn=64&fnval=1&platform=html5"
            val playResponse = URL(playUrl).readText()
            val playJson = org.json.JSONObject(playResponse)
            val durl = playJson.optJSONObject("data")?.optJSONArray("durl")?.optJSONObject(0)
            val streamUrl = durl?.optString("url", "") ?: ""

            JSONObject().apply {
                if (streamUrl.isNotEmpty()) {
                    put("url", streamUrl)
                    put("quality", quality)
                    put("source", "BILIBILI")
                } else {
                    put("error", "Stream URL not found")
                }
            }
        } catch (e: Exception) {
            JSONObject().apply { put("error", e.message) }
        }
    }

    private fun getNeteaseInfo(id: String): JSONObject {
        // TODO: 实现网易云 API 调用获取歌曲元信息（需要考虑跨域与签名）
        return JSONObject().apply {
            put("id", id)
            put("title", "Netease Song - $id")
            put("uploader", "Unknown")
            put("duration", 0)
            put("source", "NETEASE")
        }
    }

    private fun getNeteaseStreamUrl(id: String, quality: String): JSONObject {
        // TODO: 实现网易云流地址获取（需签名与账户认证）
        return JSONObject().apply {
            put("url", "https://example.com/stream/netease/$id")
            put("quality", quality)
            put("source", "NETEASE")
        }
    }
}
