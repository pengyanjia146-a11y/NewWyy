# NewPipeExtractor Capacitor Plugin (skeleton)

本目录包含一个用于在 Android (Capacitor) 上集成 NewPipeExtractor 的插件骨架。

注意：这是一个骨架实现，主要用途是帮助你在 Android Studio 中快速集成并替换 TODO 部分为真实的 NewPipeExtractor 调用。

集成步骤（推荐）：
1. 在项目中将此模块作为 Android library module 导入（或把代码移动到 `android/` 下的合适位置）。
2. 在 `settings.gradle` 中包含该 module，或在 Android Studio 中 `File -> New -> Import Module`。
3. 在 module 的 Gradle 中添加对 NewPipeExtractor 的依赖；如果使用源码引入，可将 extractor 源码作为子 module。
4. 实现 `NewPipeExtractorPlugin.kt` 中的 TODO 部分，使用 NewPipeExtractor API 获取视频信息与流 URL。
5. 在 `AndroidManifest.xml` 或 Capacitor 插件注册中暴露该插件名称 `NewPipeExtractor`。
6. 在前端使用 `services/newpipePlugin.ts` 调用 `getInfo` 与 `getStreamUrl`。

示例前端调用：
```ts
import newpipe from '../services/newpipePlugin';
const info = await newpipe.getInfo('VIDEO_ID');
const stream = await newpipe.getStreamUrl('VIDEO_ID');
```

法律与合规提示：在客户端解析并播放第三方平台媒体可能存在服务条款或版权风险，请确保使用场景合规。
