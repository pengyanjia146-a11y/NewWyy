# Create a timestamped snapshot of the project (exclude node_modules)
# Usage: run from project root: .\scripts\create_snapshot.ps1

$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$desktop = [Environment]::GetFolderPath('Desktop')
$targetRoot = Join-Path $desktop 'NewWyy_Versions'
if (-not (Test-Path $targetRoot)) { New-Item -Path $targetRoot -ItemType Directory | Out-Null }

# Read package.json version
$pkg = Join-Path $projectRoot 'package.json'
$version = '0.0.0'
if (Test-Path $pkg) {
    try { $version = (Get-Content $pkg -Raw | ConvertFrom-Json).version } catch { }
}

$timestamp = Get-Date -Format yyyyMMddHHmmss
$folderName = "NewWyy--_v${version}_$timestamp"
$dest = Join-Path $targetRoot $folderName

Write-Host "Creating snapshot: $dest"

# Copy excluding node_modules and .git (keeps size small)
$items = Get-ChildItem -Path $projectRoot -Force | Where-Object { $_.Name -ne 'node_modules' -and $_.Name -ne '.git' }
New-Item -Path $dest -ItemType Directory | Out-Null

foreach ($item in $items) {
    $srcPath = $item.FullName
    $dstPath = Join-Path $dest $item.Name
    Copy-Item -Path $srcPath -Destination $dstPath -Recurse -Force
}

Write-Host "Snapshot complete: $dest"