import { Capacitor } from '@capacitor/core';

const Plugins: any = (Capacitor as any).Plugins || (window as any).Capacitor?.Plugins || {};
const NewPipe = Plugins.NewPipeExtractor || Plugins.NewPipe || {};

export async function getInfo(id: string) {
    if (!NewPipe.getInfo) throw new Error('Native plugin not installed');
    return await NewPipe.getInfo({ id });
}

export async function getStreamUrl(id: string, quality: string = 'auto') {
    if (!NewPipe.getStreamUrl) throw new Error('Native plugin not installed');
    return await NewPipe.getStreamUrl({ id, quality });
}

export default { getInfo, getStreamUrl };
